import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import startSession from '@salesforce/apex/CopadoBuilderController.startSession';
import sendMessage from '@salesforce/apex/CopadoBuilderController.sendMessage';
import createCopadoStory from '@salesforce/apex/CopadoBuilderController.createCopadoStory';
import listCopadoUserStories from '@salesforce/apex/CopadoBuilderController.listCopadoUserStories';
import buildCode from '@salesforce/apex/CopadoBuilderController.buildCode';
import reviewCode from '@salesforce/apex/CopadoBuilderController.reviewCode';
import createTests from '@salesforce/apex/CopadoBuilderController.createTests';
import listSafeDevOrgs from '@salesforce/apex/CopadoBuilderController.listSafeDevOrgs';
import deployToDev from '@salesforce/apex/CopadoBuilderController.deployToDev';
import improveStory from '@salesforce/apex/CopadoBuilderController.improveStory';
import getMySessions from '@salesforce/apex/CopadoBuilderController.getMySessions';
import openSession from '@salesforce/apex/CopadoBuilderController.openSession';

export default class CopadoBuilderChat extends LightningElement {
  @track sessionId;
  @track messages = [];
  @track inputMessage = '';
  @track isLoading = false;
  @track waitingLabel = 'Copado is thinking';
  @track pendingUserMessage = '';

  @track score = 0;
  @track currentStep = 'Discovery';
  @track missingInfo = [];
  @track orgContextStatus = 'Connected';
  @track buildStatus = 'Not started';
  @track testStatus = 'Not started';
  @track deployStatus = 'Not ready';
  @track copadoUserStory = '';
  @track hasStory = false;

  @track orgOptions = [];
  @track selectedOrgId = '';
  @track rememberEnvironment = true;
  @track environmentHelpText =
    'Pick your Dev environment. Builder will set it on the user story before Build/Deploy.';
  @track chatSessions = [];
  @track userStoryOptions = [];
  @track selectedUserStoryId = '';
  @track lastBuildId = '';
  @track lastJobId = '';
  @track buildArtifacts = [];

  _waitingTimer;
  _lastMessagesKey = '';
  _scrollRaf;

  renderedCallback() {
    this.renderMessages();
  }

  disconnectedCallback() {
    this.clearWaitingTimer();
  }

  connectedCallback() {
    this.initSession();
  }

  async initSession() {
    this.beginWaiting('Starting Copado Builder');
    try {
      const session = await startSession();
      this.applySession(session);
      await Promise.all([this.loadOrgs(), this.loadChatSessions(), this.loadUserStories()]);
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async handleNewChat() {
    if (this.isLoading) return;
    this.beginWaiting('Starting new chat');
    try {
      const session = await startSession();
      this.applySession(session);
      await this.loadChatSessions();
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async handleOpenChat(event) {
    const id = event.currentTarget?.dataset?.id;
    if (!id || this.isLoading || id === this.sessionId) return;

    this.beginWaiting('Opening chat');
    try {
      const session = await openSession({ sessionId: id });
      this.applySession(session);
      await Promise.all([this.loadChatSessions(), this.loadOrgs(), this.loadUserStories()]);
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async loadOrgs() {
    if (!this.sessionId) return;
    try {
      const result = await listSafeDevOrgs({ sessionId: this.sessionId });
      const orgs = result?.orgs || result || [];
      this.orgOptions = orgs.map((org) => ({
        label: org.orgName,
        value: org.orgId
      }));
      if (result?.helpText) {
        this.environmentHelpText = result.helpText;
      }
      // Prefer: story env → user preference → first safe org
      const preferred =
        result?.storyEnvironmentId ||
        result?.preferredEnvironmentId ||
        (this.orgOptions.length > 0 ? this.orgOptions[0].value : '');
      if (preferred && this.orgOptions.some((o) => o.value === preferred)) {
        this.selectedOrgId = preferred;
      } else if (this.orgOptions.length > 0 && !this.selectedOrgId) {
        this.selectedOrgId = this.orgOptions[0].value;
      }
    } catch (error) {
      this.showError(error);
    }
  }

  async loadUserStories() {
    try {
      const rows = await listCopadoUserStories({ searchTerm: '' });
      this.userStoryOptions = (rows || []).map((row) => ({
        label: row.label || row.name,
        value: row.id
      }));
      // Prefer currently linked story if present in options
      if (!this.selectedUserStoryId && this.userStoryOptions.length > 0) {
        this.selectedUserStoryId = this.userStoryOptions[0].value;
      }
    } catch (error) {
      this.userStoryOptions = [];
    }
  }

  async loadChatSessions() {
    try {
      this.chatSessions = await getMySessions();
    } catch (error) {
      // History is non-critical
    }
  }

  applySession(session) {
    if (!session) return;
    this.sessionId = session.sessionId;
    this.messages = session.messages || [];
    this.score = session.score || 0;
    this.currentStep = session.currentStep || 'Discovery';
    this.missingInfo = session.missingInfo || [];
    this.orgContextStatus = session.orgContextStatus || 'Connected';
    this.buildStatus = session.buildStatus || 'Not started';
    this.testStatus = session.testStatus || 'Not started';
    this.deployStatus = session.deployStatus || 'Not ready';
    this.copadoUserStory = session.copadoUserStory || '';
    this.hasStory = !!this.copadoUserStory;
    this.lastBuildId = session.lastBuildId || '';
    this.lastJobId = session.lastJobId || '';
    this.buildArtifacts = session.buildArtifacts || [];
    // Prefer linked story record for the update picker
    if (session.storyRecordId) {
      this.selectedUserStoryId = session.storyRecordId;
    }
  }

  messagesRenderKey() {
    const parts = (this.messages || []).map(
      (msg) => `${msg.role || ''}:${msg.message || ''}`
    );
    return [
      parts.join('\u0001'),
      this.pendingUserMessage || '',
      this.isLoading ? '1' : '0',
      this.waitingLabel || ''
    ].join('\u0002');
  }

  renderMessages() {
    const container = this.template.querySelector('.chat-messages');
    if (!container) return;

    const key = this.messagesRenderKey();
    if (key === this._lastMessagesKey) {
      return;
    }
    this._lastMessagesKey = key;

    container.innerHTML = '';
    this.messages.forEach((msg) => {
      const bubble = document.createElement('div');
      bubble.className = `message-bubble message-${(msg.role || 'assistant').toLowerCase()}`;
      bubble.textContent = msg.message;
      container.appendChild(bubble);
    });

    // Optimistic user bubble while waiting for Apex round-trip
    if (this.pendingUserMessage) {
      const pending = document.createElement('div');
      pending.className = 'message-bubble message-user';
      pending.textContent = this.pendingUserMessage;
      container.appendChild(pending);
    }

    // Inline typing indicator instead of full-screen spinner
    if (this.isLoading) {
      const typing = document.createElement('div');
      typing.className = 'message-bubble message-assistant message-typing';
      typing.setAttribute('aria-live', 'polite');
      typing.innerHTML =
        `<span class="typing-label">${this.escapeHtml(this.waitingLabel)}</span>` +
        '<span class="typing-dots" aria-hidden="true"><span></span><span></span><span></span></span>';
      container.appendChild(typing);
    }

    const anchor = document.createElement('div');
    anchor.className = 'chat-scroll-anchor';
    anchor.setAttribute('aria-hidden', 'true');
    container.appendChild(anchor);

    this.scrollChatToBottom();
  }

  scrollChatToBottom() {
    if (this._scrollRaf) {
      cancelAnimationFrame(this._scrollRaf);
    }
    const run = () => {
      const container = this.template.querySelector('.chat-messages');
      if (!container) return;
      // Only scroll the chat pane — never scrollIntoView (that can jump the page)
      container.scrollTop = container.scrollHeight;
    };
    // Double rAF so layout (and typing bubble) settles before scrolling
    this._scrollRaf = requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        run();
        // One more tick for Lightning layout / toast chrome
        window.setTimeout(run, 50);
      });
    });
  }

  escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  beginWaiting(label, pendingUserMessage = '') {
    this.clearWaitingTimer();
    this.isLoading = true;
    this.waitingLabel = label || 'Copado is thinking';
    this.pendingUserMessage = pendingUserMessage || '';
    this._waitingTimer = window.setTimeout(() => {
      this.waitingLabel = 'Still working — Copado AI can take a bit';
    }, 15000);
    // Ensure latest content stays visible when actions start
    Promise.resolve().then(() => this.scrollChatToBottom());
  }

  endWaiting() {
    this.clearWaitingTimer();
    this.isLoading = false;
    this.pendingUserMessage = '';
    this.waitingLabel = 'Copado is thinking';
    Promise.resolve().then(() => this.scrollChatToBottom());
  }

  clearWaitingTimer() {
    if (this._waitingTimer) {
      window.clearTimeout(this._waitingTimer);
      this._waitingTimer = undefined;
    }
  }

  handleInputChange(event) {
    this.inputMessage = event.target.value;
  }

  handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.handleSend();
    }
  }

  async handleSend() {
    const text = this.inputMessage?.trim();
    if (!text || this.isLoading) return;

    this.inputMessage = '';
    this.beginWaiting('Copado is thinking', text);
    try {
      const session = await sendMessage({
        sessionId: this.sessionId,
        message: text
      });
      this.applySession(session);
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
      this.loadChatSessions();
    }
  }

  async handleImproveStory() {
    this.scrollChatToBottom();
    await this.runAction(
      () => improveStory({ sessionId: this.sessionId }),
      'Improving your story'
    );
  }

  async handleCreateStory() {
    this.scrollChatToBottom();
    await this.runAction(
      () =>
        createCopadoStory({
          sessionId: this.sessionId,
          updateExisting: false,
          targetStoryId: null
        }),
      'Creating Copado story'
    );
    await Promise.all([this.loadChatSessions(), this.loadUserStories(), this.loadOrgs()]);
  }

  async handleUpdateStory() {
    this.scrollChatToBottom();
    if (!this.selectedUserStoryId) {
      this.showToast(
        'Select a story',
        'Choose a Copado User Story to update from the Status panel.',
        'warning'
      );
      return;
    }
    await this.runAction(
      () =>
        createCopadoStory({
          sessionId: this.sessionId,
          updateExisting: true,
          targetStoryId: this.selectedUserStoryId
        }),
      'Updating Copado story'
    );
    await Promise.all([this.loadChatSessions(), this.loadUserStories(), this.loadOrgs()]);
  }

  handleBuildCode() {
    this.scrollChatToBottom();
    if (!this.selectedOrgId) {
      this.showToast(
        'Select a Dev environment',
        'Choose your Dev environment in the Status panel. Builder will add it to the user story.',
        'warning'
      );
      return;
    }
    const storyLabel = this.copadoUserStory || 'the linked Copado user story';
    const orgName =
      this.orgOptions.find((o) => o.value === this.selectedOrgId)?.label || 'selected Dev environment';
    const confirmed = window.confirm(
      `Build metadata for ${storyLabel}?\n\n`
        + `Dev environment: ${orgName}\n\n`
        + 'Copado Builder will generate Salesforce metadata based on the story '
        + '(custom fields, objects, validation rules, Apex, triggers, LWC, layouts, '
        + 'permission sets, etc. as needed), set this environment on the user story, '
        + 'then prepare a Copado commit.\n\n'
        + 'Review the generated artifacts and Copado job before deploying.'
    );
    if (confirmed) {
      this.executeBuildCode();
    }
  }

  async executeBuildCode() {
    await this.runAction(
      () =>
        buildCode({
          sessionId: this.sessionId,
          environmentId: this.selectedOrgId,
          rememberPreference: this.rememberEnvironment
        }),
      'Building metadata package'
    );
    await this.loadOrgs();
  }

  async handleReviewCode() {
    this.scrollChatToBottom();
    await this.runAction(
      () => reviewCode({ sessionId: this.sessionId }),
      'Reviewing code'
    );
  }

  async handleCreateTests() {
    this.scrollChatToBottom();
    await this.runAction(
      () => createTests({ sessionId: this.sessionId }),
      'Creating tests'
    );
  }

  handleDeployClick() {
    this.scrollChatToBottom();
    if (!this.selectedOrgId) {
      this.showToast(
        'Select a Dev environment',
        'Choose your Dev environment in the Status panel. Builder will add it to the user story.',
        'warning'
      );
      return;
    }
    const orgName = this.orgOptions.find((o) => o.value === this.selectedOrgId)?.label || 'dev sandbox';
    const confirmed = window.confirm(
      `Deploy to ${orgName}?\n\n`
        + 'This will set that environment on the user story (if needed) and deploy to the Dev sandbox. '
        + 'Production is never allowed.'
    );
    if (confirmed) {
      this.executeDeploy();
    }
  }

  async executeDeploy() {
    await this.runAction(
      () =>
        deployToDev({
          sessionId: this.sessionId,
          orgId: this.selectedOrgId,
          confirmed: true,
          rememberPreference: this.rememberEnvironment
        }),
      'Deploying to dev'
    );
    await Promise.all([this.loadChatSessions(), this.loadOrgs()]);
  }

  handleOrgChange(event) {
    this.selectedOrgId = event.detail.value;
  }

  handleRememberEnvironmentChange(event) {
    this.rememberEnvironment = event.target.checked;
  }

  handleUserStoryChange(event) {
    this.selectedUserStoryId = event.detail.value;
  }

  async runAction(actionFn, waitingLabel = 'Working on it') {
    this.beginWaiting(waitingLabel);
    try {
      const result = await actionFn();
      if (result?.session) {
        this.applySession(result.session);
      }
      if (result?.success) {
        this.showToast('Success', result.message || 'Done.', 'success');
      } else {
        this.showToast('Notice', result?.message || 'Action did not complete.', 'warning');
      }
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
      this.loadChatSessions();
    }
  }

  showError(error) {
    const message =
      error?.body?.message ||
      error?.body?.pageErrors?.[0]?.message ||
      error?.body?.fieldErrors?.[Object.keys(error?.body?.fieldErrors || {})[0]]?.[0]?.message ||
      error?.message ||
      (typeof error === 'string' ? error : null) ||
      JSON.stringify(error?.body || error) ||
      'Something went wrong.';
    this.showToast('Error', message, 'error');
  }

  showToast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }

  get scoreDisplay() {
    return `${this.score}%`;
  }

  get scoreClass() {
    if (this.score >= 75) return 'status-value score-good';
    if (this.score >= 50) return 'status-value score-medium';
    return 'status-value score-low';
  }

  get missingInfoDisplay() {
    return this.missingInfo.length > 0 ? this.missingInfo.join(', ') : 'None';
  }

  get isCreateStoryDisabled() {
    return this.isLoading || this.score < 40;
  }

  get isUpdateStoryDisabled() {
    return this.isLoading || this.score < 40 || !this.selectedUserStoryId;
  }

  get showUserStorySelect() {
    return this.score >= 40;
  }

  get hasBuildArtifacts() {
    return this.buildArtifacts && this.buildArtifacts.length > 0;
  }

  get artifactsDisplay() {
    if (!this.buildArtifacts || this.buildArtifacts.length === 0) {
      return 'None';
    }
    return this.buildArtifacts
      .map((p) => {
        const parts = String(p).split('/');
        return parts[parts.length - 1] || p;
      })
      .join(', ');
  }

  get showOrgSelect() {
    return this.hasStory && this.orgOptions.length > 0;
  }

  get isStoryActionDisabled() {
    return this.isLoading || !this.hasStory || !this.selectedOrgId;
  }

  get isDeployDisabled() {
    return this.isLoading || !this.hasStory || !this.selectedOrgId || this.deployStatus === 'Complete';
  }

  get hasChatSessions() {
    return this.chatSessions && this.chatSessions.length > 0;
  }

  get chatSessionsView() {
    const activeId = this.sessionId;
    return (this.chatSessions || []).map((chat) => ({
      ...chat,
      itemClass:
        chat.sessionId === activeId ? 'chat-item chat-item-active' : 'chat-item'
    }));
  }
}
