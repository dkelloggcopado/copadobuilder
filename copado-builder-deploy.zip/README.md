# Copado Builder POC

A deployable Salesforce package for a chat-guided Copado user story builder.

## Quick Deploy

```bash
cd ~/Projects/copado-builder
sf org login web --instance-url https://test.salesforce.com --alias copado-psa
./scripts/deploy.sh copado-psa
```

See **[DEPLOY.md](DEPLOY.md)** for full instructions and post-deploy steps.

## Package Contents

- **3 custom objects** — Session, Message, Action
- **1 custom metadata type** — `Copado_Builder_Settings__mdt` (org ID, API config)
- **3 Apex classes** — Controller, API service, tests
- **1 LWC** — `copadoBuilderChat`
- **Lightning app** — Copado Builder (app + tab + page)
- **Integration** — Remote Site + External Credential + Named Credential
- **Permission set** — `Copado_Builder_User`
- **Manifest** — `manifest/package.xml`

## Post-Deploy (manual)

1. Add Copado AI Personal Access Key to External Credential **Copado AI API Key**
2. Set Organization Id in **Copado Builder Settings** custom metadata
3. Assign **Copado Builder User** permission set

The app runs in **mock mode** by default (`Use Mock API = true`) until you configure the API key and flip the setting.

## Project Structure

```
copado-builder/
├── force-app/main/default/   # All Salesforce metadata
├── manifest/package.xml      # Deploy manifest
├── scripts/deploy.sh         # One-command deploy script
├── config/                   # Scratch org definition
├── DEPLOY.md                 # Detailed deploy guide
└── sfdx-project.json
```
