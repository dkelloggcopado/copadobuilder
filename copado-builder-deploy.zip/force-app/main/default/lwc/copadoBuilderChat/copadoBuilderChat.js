import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import startSession from '@salesforce/apex/CopadoBuilderController.startSession';
import sendMessage from '@salesforce/apex/CopadoBuilderController.sendMessage';
import createCopadoStory from '@salesforce/apex/CopadoBuilderController.createCopadoStory';
import buildCode from '@salesforce/apex/CopadoBuilderController.buildCode';
import reviewCode from '@salesforce/apex/CopadoBuilderController.reviewCode';
import createTests from '@salesforce/apex/CopadoBuilderController.createTests';
import listSafeDevOrgs from '@salesforce/apex/CopadoBuilderController.listSafeDevOrgs';
import deployToDev from '@salesforce/apex/CopadoBuilderController.deployToDev';
import improveStory from '@salesforce/apex/CopadoBuilderController.improveStory';
import getStoryHistory from '@salesforce/apex/CopadoBuilderController.getStoryHistory';

export default class CopadoBuilderChat extends LightningElement {
  @track sessionId;
  @track messages = [];
  @track inputMessage = '';
  @track isLoading = false;

  @track score = 0;
  @track currentStep = 'Discovery';
  @track missingInfo = [];
  @track orgContextStatus = 'Connected';
  @track buildStatus = 'Not started';
  @track testStatus = 'Not started';
  @track deployStatus = 'Not ready';
  @track copadoUserStory = '';
  @track hasStory = false;

  @track orgOptions = [];
  @track selectedOrgId = '';
  @track storyHistory = [];

  renderedCallback() {
    this.renderMessages();
  }

  connectedCallback() {
    this.initSession();
    this.loadHistory();
  }

  async initSession() {
    this.isLoading = true;
    try {
      const session = await startSession();
      this.applySession(session);
      await this.loadOrgs();
    } catch (error) {
      this.showError(error);
    } finally {
      this.isLoading = false;
    }
  }

  async loadOrgs() {
    if (!this.sessionId) return;
    try {
      const orgs = await listSafeDevOrgs({ sessionId: this.sessionId });
      this.orgOptions = orgs.map((org) => ({
        label: org.orgName,
        value: org.orgId
      }));
      if (this.orgOptions.length > 0) {
        this.selectedOrgId = this.orgOptions[0].value;
      }
    } catch (error) {
      this.showError(error);
    }
  }

  async loadHistory() {
    try {
      this.storyHistory = await getStoryHistory();
    } catch (error) {
      // History is non-critical
    }
  }

  applySession(session) {
    if (!session) return;
    this.sessionId = session.sessionId;
    this.messages = session.messages || [];
    this.score = session.score || 0;
    this.currentStep = session.currentStep || 'Discovery';
    this.missingInfo = session.missingInfo || [];
    this.orgContextStatus = session.orgContextStatus || 'Connected';
    this.buildStatus = session.buildStatus || 'Not started';
    this.testStatus = session.testStatus || 'Not started';
    this.deployStatus = session.deployStatus || 'Not ready';
    this.copadoUserStory = session.copadoUserStory || '';
    this.hasStory = !!this.copadoUserStory;
  }

  renderMessages() {
    const container = this.template.querySelector('.chat-messages');
    if (!container) return;

    container.innerHTML = '';
    this.messages.forEach((msg) => {
      const bubble = document.createElement('div');
      bubble.className = `message-bubble message-${msg.role.toLowerCase()}`;
      bubble.textContent = msg.message;
      container.appendChild(bubble);
    });
    container.scrollTop = container.scrollHeight;
  }

  handleInputChange(event) {
    this.inputMessage = event.target.value;
  }

  handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.handleSend();
    }
  }

  async handleSend() {
    const text = this.inputMessage?.trim();
    if (!text || this.isLoading) return;

    this.isLoading = true;
    this.inputMessage = '';
    try {
      const session = await sendMessage({
        sessionId: this.sessionId,
        message: text
      });
      this.applySession(session);
    } catch (error) {
      this.showError(error);
    } finally {
      this.isLoading = false;
    }
  }

  async handleImproveStory() {
    await this.runAction(() => improveStory({ sessionId: this.sessionId }));
  }

  async handleCreateStory() {
    await this.runAction(() => createCopadoStory({ sessionId: this.sessionId }));
    await this.loadHistory();
  }

  async handleBuildCode() {
    await this.runAction(() => buildCode({ sessionId: this.sessionId }));
  }

  async handleReviewCode() {
    await this.runAction(() => reviewCode({ sessionId: this.sessionId }));
  }

  async handleCreateTests() {
    await this.runAction(() => createTests({ sessionId: this.sessionId }));
  }

  handleDeployClick() {
    const orgName = this.orgOptions.find((o) => o.value === this.selectedOrgId)?.label || 'dev sandbox';
    const confirmed = window.confirm(
      `Deploy to ${orgName}?\n\nThis will deploy your story to the dev sandbox. Production is never allowed.`
    );
    if (confirmed) {
      this.executeDeploy();
    }
  }

  async executeDeploy() {
    await this.runAction(() =>
      deployToDev({
        sessionId: this.sessionId,
        orgId: this.selectedOrgId,
        confirmed: true
      })
    );
    await this.loadHistory();
  }

  handleOrgChange(event) {
    this.selectedOrgId = event.detail.value;
  }

  async runAction(actionFn) {
    this.isLoading = true;
    try {
      const result = await actionFn();
      if (result.session) {
        this.applySession(result.session);
      }
      if (result.success) {
        this.showToast('Success', result.message, 'success');
      } else {
        this.showToast('Notice', result.message, 'warning');
      }
    } catch (error) {
      this.showError(error);
    } finally {
      this.isLoading = false;
    }
  }

  showError(error) {
    const message = error?.body?.message || error?.message || 'Something went wrong.';
    this.showToast('Error', message, 'error');
  }

  showToast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }

  get scoreDisplay() {
    return `${this.score}%`;
  }

  get scoreClass() {
    if (this.score >= 75) return 'status-value score-good';
    if (this.score >= 50) return 'status-value score-medium';
    return 'status-value score-low';
  }

  get missingInfoDisplay() {
    return this.missingInfo.length > 0 ? this.missingInfo.join(', ') : 'None';
  }

  get isCreateStoryDisabled() {
    return this.isLoading || this.hasStory;
  }

  get isStoryActionDisabled() {
    return this.isLoading || !this.hasStory;
  }

  get isDeployDisabled() {
    return this.isLoading || !this.hasStory || this.deployStatus === 'Complete';
  }

  get showOrgSelect() {
    return this.hasStory && this.orgOptions.length > 0;
  }

  get hasHistory() {
    return this.storyHistory && this.storyHistory.length > 0;
  }
}
