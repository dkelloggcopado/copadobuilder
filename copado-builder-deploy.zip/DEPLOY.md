# Copado Builder — Deploy Guide

## One-command deploy

```bash
cd ~/Projects/copado-builder

# Log in once
sf org login web --instance-url https://test.salesforce.com --alias copado-psa

# Deploy everything + run tests + assign permission set
chmod +x scripts/deploy.sh
./scripts/deploy.sh copado-psa
```

Or deploy manually:

```bash
sf project deploy start --source-dir force-app --target-org copado-psa --wait 15
sf apex run test --tests CopadoBuilderControllerTest --target-org copado-psa --result-format human --wait 10
sf org assign permset --name Copado_Builder_User --target-org copado-psa
```

Or deploy from manifest:

```bash
sf project deploy start --manifest manifest/package.xml --target-org copado-psa --wait 15
```

---

## What gets deployed

| Category | Components |
|----------|------------|
| **Objects** | `AI_Builder_Session__c`, `AI_Builder_Message__c`, `AI_Builder_Action__c` |
| **Config** | `Copado_Builder_Settings__mdt` + Default record |
| **Apex** | `CopadoBuilderController`, `CopadoAiApiService`, `CopadoBuilderControllerTest` |
| **LWC** | `copadoBuilderChat` |
| **App** | Copado Builder app, tab, flexipage |
| **Integration** | Remote Site, External Credential, Named Credential |
| **Security** | `Copado_Builder_User` permission set |

---

## Post-deploy (required — cannot be in metadata)

### 1. Add your Copado AI API key

Secrets cannot be deployed via metadata. After deploy:

1. **Setup** → **Named Credentials** → **External Credentials** tab
2. Open **Copado AI API Key**
3. **Principals** → **Default** → **New Secret**
4. Paste your Copado AI **Personal Access Key**
5. Save

### 2. Configure Custom Metadata

1. **Setup** → search **Custom Metadata Types**
2. **Copado Builder Settings** → **Manage Records** → **Default**
3. Set:

| Field | Value |
|-------|-------|
| **Organization Id** | Your Copado AI org ID |
| **Base Url** | `https://copadogpt-api.robotic.copado.com` (or your region) |
| **Workspace Id** | Optional — leave blank to auto-create per session |
| **Use Mock API** | ✅ checked for POC demo; uncheck when API key is set |

### 3. Assign permission set to users

```bash
sf org assign permset --name Copado_Builder_User --target-org copado-psa --on-behalf-of your.user@copado.com.psa
```

Or via Setup → Permission Sets → Copado Builder User → Manage Assignments.

### 4. Open the app

App Launcher → **Copado Builder**

---

## Verify API connectivity

Developer Console → Execute Anonymous (replace `YOUR_ORG_ID`):

```apex
HttpRequest req = new HttpRequest();
req.setEndpoint('callout:Copado_AI_API/organizations/YOUR_ORG_ID/workspaces');
req.setMethod('GET');
req.setHeader('Content-Type', 'application/json');
HttpResponse res = new Http().send(req);
System.debug(res.getStatusCode() + ' ' + res.getBody());
```

Expected: `200` with workspace list JSON.

---

## Region URLs

| Region | Base URL |
|--------|----------|
| US | `https://copadogpt-api.robotic.copado.com` |
| EU | `https://copadogpt-api.eu-robotic.copado.com` |
| Australia | `https://copadogpt-api.au-robotic.copado.com` |
| Singapore | `https://copadogpt-api.sg-robotic.copado.com` |

Update **Base Url** in Custom Metadata and redeploy Named Credential URL if needed.

---

## Troubleshooting

| Error | Fix |
|-------|-----|
| `Unauthorized endpoint` | Remote Site `Copado_AI_API` not deployed — redeploy `force-app` |
| `401 Unauthorized` | API key secret missing on External Credential principal |
| `Named Credential not found` | Named Credential API name must be `Copado_AI_API` |
| App not visible | Assign `Copado_Builder_User` permission set |
| Tests fail | Deploy all objects first, then Apex |
