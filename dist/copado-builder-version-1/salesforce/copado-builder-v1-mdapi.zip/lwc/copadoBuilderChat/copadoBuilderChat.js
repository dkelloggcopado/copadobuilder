import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { EnclosingUtilityId } from 'lightning/platformUtilityBarApi';
import startSession from '@salesforce/apex/CopadoBuilderController.startSession';
import resumeOrStartSession from '@salesforce/apex/CopadoBuilderController.resumeOrStartSession';
import sendMessage from '@salesforce/apex/CopadoBuilderController.sendMessage';
import pollAiReply from '@salesforce/apex/CopadoBuilderController.pollAiReply';
import createCopadoStory from '@salesforce/apex/CopadoBuilderController.createCopadoStory';
import listCopadoUserStories from '@salesforce/apex/CopadoBuilderController.listCopadoUserStories';
import openCopadoUserStory from '@salesforce/apex/CopadoBuilderController.openCopadoUserStory';
import buildCode from '@salesforce/apex/CopadoBuilderController.buildCode';
import refreshJobStatus from '@salesforce/apex/CopadoBuilderController.refreshJobStatus';
import linkUserStoryCommitFromLastJob from '@salesforce/apex/CopadoBuilderController.linkUserStoryCommitFromLastJob';
import listSafeDevOrgs from '@salesforce/apex/CopadoBuilderController.listSafeDevOrgs';
import listCopadoProjects from '@salesforce/apex/CopadoBuilderController.listCopadoProjects';
import savePreferredProject from '@salesforce/apex/CopadoBuilderController.savePreferredProject';
import commitFromDev from '@salesforce/apex/CopadoBuilderController.commitFromDev';
import improveStory from '@salesforce/apex/CopadoBuilderController.improveStory';
import getMySessions from '@salesforce/apex/CopadoBuilderController.getMySessions';
import openSession from '@salesforce/apex/CopadoBuilderController.openSession';
import deleteSession from '@salesforce/apex/CopadoBuilderController.deleteSession';
import connectOrgIntelligence from '@salesforce/apex/CopadoBuilderController.connectOrgIntelligence';
import listOrgIntelligenceIntegrations from '@salesforce/apex/CopadoBuilderController.listOrgIntelligenceIntegrations';
import ensureOrgIntelligenceReady from '@salesforce/apex/CopadoBuilderController.ensureOrgIntelligenceReady';
import saveSessionOrgCredential from '@salesforce/apex/CopadoBuilderController.saveSessionOrgCredential';

export default class CopadoBuilderChat extends NavigationMixin(LightningElement) {
  /** App Manager toggle for utility panel compact layout. */
  @api utilityCompact = false;

  @track sessionId;
  @track messages = [];
  @track inputMessage = '';
  @track isLoading = false;
  @track waitingLabel = 'Copado is thinking';
  @track pendingUserMessage = '';

  @track score = 0;
  @track currentStep = 'Discovery';
  @track missingInfo = [];
  @track orgContextStatus = 'Not connected';
  @track orgIntelligenceIntegrationId = '';
  @track buildStatus = 'Not started';
  @track testStatus = 'Not started';
  @track deployStatus = 'Not ready';
  @track copadoUserStory = '';
  @track storyRecordId = '';
  @track storyName = '';
  @track storyTitle = '';
  @track hasStory = false;

  @track projectOptions = [];
  @track selectedProjectId = '';
  @track projectHelpText =
    'Choose the Copado Project whose pipeline contains your Dev environment.';
  @track orgOptions = [];
  @track selectedOrgId = '';
  @track integrationOptions = [];
  @track selectedIntegrationId = '';
  @track integrationsLoaded = false;
  @track rememberEnvironment = true;
  @track environmentHelpText =
    'Connect Org Intelligence anytime — even before a story — so chat can use live Dev metadata.';
  @track chatSessions = [];
  @track userStoryOptions = [];
  @track selectedUserStoryId = '';
  @track storySearchTerm = '';
  @track isChangingStory = false;
  @track lastBuildId = '';
  @track lastJobId = '';
  @track lastJobStatus = '';
  @track lastJobSummary = '';
  @track lastJobFailed = false;
  @track lastJobComplete = false;
  @track buildArtifacts = [];

  _waitingTimer;
  _lastMessagesKey = '';
  _scrollRaf;
  _jobPollTimer;
  _jobPollAttempts = 0;
  _aiPollTimer;
  _aiPollAttempts = 0;

  @wire(EnclosingUtilityId)
  utilityId;

  @track showChatsInCompact = false;
  @track showStatusInCompact = false;

  get isCompact() {
    // Aura Global Action often passes the boolean @api as the string "true".
    return (
      !!this.utilityId
      || this.utilityCompact === true
      || this.utilityCompact === 'true'
    );
  }

  /** @deprecated alias — compact covers utility + global action */
  get isUtilityBar() {
    return this.isCompact;
  }

  get showBrandChrome() {
    return !this.isCompact;
  }

  get showChatHeader() {
    return !this.isCompact;
  }

  get showChatsPanel() {
    return !this.isCompact || this.showChatsInCompact;
  }

  get showStatusPanel() {
    return !this.isCompact || this.showStatusInCompact;
  }

  get chatsToggleLabel() {
    return this.showChatsInCompact ? 'Hide Chats' : 'Chats';
  }

  get statusToggleLabel() {
    return this.showStatusInCompact ? 'Hide Status' : 'Status';
  }

  get rootClass() {
    return this.isCompact ? 'builder-root builder-root_compact' : 'builder-root';
  }

  get shellClass() {
    return this.isCompact ? 'builder-shell builder-shell_utility' : 'builder-shell';
  }

  get layoutClass() {
    return this.isCompact ? 'builder-layout builder-layout_utility' : 'builder-layout';
  }

  toggleChatsPanel() {
    this.showChatsInCompact = !this.showChatsInCompact;
    if (this.showChatsInCompact) {
      this.showStatusInCompact = false;
    }
  }

  toggleStatusPanel() {
    this.showStatusInCompact = !this.showStatusInCompact;
    if (this.showStatusInCompact) {
      this.showChatsInCompact = false;
    }
  }

  renderedCallback() {
    this.renderMessages();
  }

  disconnectedCallback() {
    this.clearWaitingTimer();
    this.clearJobPoll();
    this.clearAiPoll();
  }

  connectedCallback() {
    this.initSession();
  }

  async initSession() {
    this.beginWaiting('Opening Copado Builder');
    try {
      const session = await resumeOrStartSession();
      this.applySession(session);
      await Promise.all([
        this.loadProjects(),
        this.loadChatSessions(),
        this.loadUserStories()
      ]);
      await this.loadOrgs();
      await this.loadIntegrations();
      await this.checkExistingOrgIntelligence();
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async handleNewChat() {
    if (this.isLoading) return;
    this.beginWaiting('Starting new chat');
    try {
      const session = await startSession();
      this.isChangingStory = false;
      this.applySession(session);
      await this.loadChatSessions();
      await this.loadProjects();
      await this.loadOrgs();
      await this.loadIntegrations();
      await this.checkExistingOrgIntelligence();
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async handleOpenChat(event) {
    const id = event.currentTarget?.dataset?.id;
    if (!id || this.isLoading || id === this.sessionId) return;

    this.beginWaiting('Opening chat');
    try {
      const session = await openSession({ sessionId: id });
      this.applySession(session);
      await Promise.all([this.loadChatSessions(), this.loadProjects(), this.loadUserStories()]);
      await this.loadOrgs();
      await this.loadIntegrations();
      await this.checkExistingOrgIntelligence();
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async handleDeleteChat(event) {
    event.stopPropagation();
    const id = event.currentTarget?.dataset?.id;
    const name = event.currentTarget?.dataset?.name || 'this chat';
    if (!id || this.isLoading) return;

    // eslint-disable-next-line no-alert
    const ok = window.confirm(
      `Delete "${name}"?\n\nThis removes it from Copado Builder and tries to delete the linked Copado AI chat too.`
    );
    if (!ok) return;

    this.beginWaiting('Deleting chat');
    try {
      const session = await deleteSession({ sessionId: id });
      this.isChangingStory = false;
      this.applySession(session);
      await Promise.all([
        this.loadChatSessions(),
        this.loadProjects(),
        this.loadUserStories()
      ]);
      await this.loadOrgs();
      await this.loadIntegrations();
      this.showToast('Deleted', 'Chat removed.', 'success');
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async loadProjects() {
    if (!this.sessionId) return;
    try {
      const result = await listCopadoProjects({ sessionId: this.sessionId });
      const projects = result?.projects || [];
      this.projectOptions = projects.map((p) => ({
        label: p.projectName,
        value: p.projectId
      }));
      if (result?.helpText) {
        this.projectHelpText = result.helpText;
      }
      const preferred =
        result?.storyProjectId ||
        result?.preferredProjectId ||
        (this.projectOptions.length > 0 ? this.projectOptions[0].value : '');
      if (preferred && this.projectOptions.some((o) => o.value === preferred)) {
        this.selectedProjectId = preferred;
      } else if (this.projectOptions.length > 0 && !this.selectedProjectId) {
        this.selectedProjectId = this.projectOptions[0].value;
      }
    } catch (error) {
      this.showError(error);
    }
  }

  async loadOrgs() {
    if (!this.sessionId) return;
    try {
      const result = await listSafeDevOrgs({
        sessionId: this.sessionId,
        projectId: this.selectedProjectId || null
      });
      const orgs = result?.orgs || result || [];
      this.orgOptions = orgs.map((org) => ({
        label: org.orgName,
        value: org.orgId
      }));
      if (result?.helpText) {
        this.environmentHelpText = result.helpText;
      }
      if (
        result?.projectId &&
        this.projectOptions.some((o) => o.value === result.projectId)
      ) {
        this.selectedProjectId = result.projectId;
      }
      const preferred =
        result?.storyEnvironmentId ||
        result?.preferredEnvironmentId ||
        (this.orgOptions.length > 0 ? this.orgOptions[0].value : '');
      if (preferred && this.orgOptions.some((o) => o.value === preferred)) {
        this.selectedOrgId = preferred;
      } else if (this.orgOptions.length > 0) {
        this.selectedOrgId = this.orgOptions[0].value;
      } else {
        this.selectedOrgId = '';
      }
    } catch (error) {
      this.showError(error);
    }
  }

  async loadIntegrations() {
    if (!this.sessionId) return;
    try {
      const rows = await listOrgIntelligenceIntegrations({ sessionId: this.sessionId });
      this.integrationOptions = (rows || []).map((row) => ({
        label: row.label || row.name || row.id,
        value: row.id,
        connected: row.connected === true,
        name: row.name || ''
      }));
      this.integrationsLoaded = true;
      const preferred =
        this.orgIntelligenceIntegrationId
        || this.selectedIntegrationId
        || '';
      if (preferred && this.integrationOptions.some((o) => o.value === preferred)) {
        this.selectedIntegrationId = preferred;
      } else {
        const userLevel = (rows || []).find(
          (r) => (r.name || '').toLowerCase() === 'user level' && r.connected === true
        );
        const anyConnected = (rows || []).find((r) => r.connected === true);
        if (userLevel?.id) {
          this.selectedIntegrationId = userLevel.id;
        } else if (anyConnected?.id) {
          this.selectedIntegrationId = anyConnected.id;
        } else if (this.integrationOptions.length > 0) {
          this.selectedIntegrationId = this.integrationOptions[0].value;
        } else {
          this.selectedIntegrationId = '';
        }
      }
      // Picker only — Connected status comes from checkExistingOrgIntelligence / Connect.
    } catch (error) {
      this.integrationOptions = [];
      this.integrationsLoaded = true;
    }
  }

  /**
   * Once per chat: if Copado already has a connected integration (e.g. User Level),
   * mark this session Connected and store the id for chat. Does not re-bind credentials.
   */
  async checkExistingOrgIntelligence() {
    if (!this.sessionId) return;
    if (this._oiCheckedSessionId === this.sessionId) return;
    this._oiCheckedSessionId = this.sessionId;

    // Already Connected with an id — nothing to discover.
    if (
      this.isOrgContextConnected
      && this.orgIntelligenceIntegrationId
    ) {
      return;
    }

    // Prefer an already-connected row from the picker list (no extra Apex if possible).
    const connected =
      this.integrationOptions.find(
        (o) => o.connected === true && (o.name || '').toLowerCase() === 'user level'
      )
      || this.integrationOptions.find((o) => o.connected === true);

    if (connected?.value) {
      // Light session update only — no credential bind.
      await this.syncOrgIntelligence(false);
      return;
    }

    // List may have loaded empty before workspace existed; one light ensure is fine.
    await this.syncOrgIntelligence(false);
  }

  /**
   * bindCredential=false: list + store Connected/id.
   * bindCredential=true: re-bind Dev org (org change / Connect).
   */
  async syncOrgIntelligence(bindCredential = false) {
    if (!this.sessionId) return;
    try {
      const session = await ensureOrgIntelligenceReady({
        sessionId: this.sessionId,
        orgCredentialId: this.selectedOrgId || null,
        preferredIntegrationId: this.selectedIntegrationId || null,
        bindCredential: bindCredential === true
      });
      if (session) {
        this.applySession(session);
      }
    } catch (error) {
      // Non-fatal — user can still click Connect / Reconnect.
    }
  }

  async loadUserStories() {
    try {
      const rows = await listCopadoUserStories({
        searchTerm: this.storySearchTerm || ''
      });
      this.userStoryOptions = (rows || []).map((row) => ({
        label: row.label || row.name,
        value: row.id
      }));
      // Prefer currently linked story if present in options
      if (!this.selectedUserStoryId && this.userStoryOptions.length > 0) {
        this.selectedUserStoryId = this.userStoryOptions[0].value;
      }
    } catch (error) {
      this.userStoryOptions = [];
    }
  }

  handleStorySearchChange(event) {
    this.storySearchTerm = event.target.value || '';
  }

  handleStorySearchKeyDown(event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      this.handleStorySearch();
    }
  }

  async handleStorySearch() {
    this.isLoading = true;
    try {
      await this.loadUserStories();
    } finally {
      this.isLoading = false;
    }
  }

  async handleUseExistingStory() {
    if (!this.selectedUserStoryId) {
      this.showToast('Select a story', 'Pick an existing Copado User Story first.', 'warning');
      return;
    }
    this.isLoading = true;
    this.waitingLabel = 'Loading existing story';
    try {
      const result = await openCopadoUserStory({
        sessionId: this.sessionId,
        userStoryId: this.selectedUserStoryId
      });
      if (result?.success) {
        this.applySession(result.session);
        this.isChangingStory = false;
        this.showToast('Success', result.message || 'Story loaded.', 'success');
        await Promise.all([this.loadProjects(), this.loadOrgs(), this.loadChatSessions()]);
      } else {
        this.showToast('Notice', result?.message || 'Could not open story.', 'warning');
      }
    } catch (error) {
      this.showError(error);
    } finally {
      this.isLoading = false;
      this.waitingLabel = 'Copado is thinking';
    }
  }

  async loadChatSessions() {
    try {
      this.chatSessions = await getMySessions();
    } catch (error) {
      // History is non-critical
    }
  }

  applySession(session) {
    if (!session) return;
    this.sessionId = session.sessionId;
    this.messages = session.messages || [];
    this.score = session.score || 0;
    this.currentStep = session.currentStep || 'Discovery';
    this.missingInfo = session.missingInfo || [];
    this.orgContextStatus = session.orgContextStatus || 'Not connected';
    this.orgIntelligenceIntegrationId = session.orgIntelligenceIntegrationId || '';
    if (
      this.orgIntelligenceIntegrationId
      && this.integrationOptions.some((o) => o.value === this.orgIntelligenceIntegrationId)
    ) {
      this.selectedIntegrationId = this.orgIntelligenceIntegrationId;
    }
    this.buildStatus = session.buildStatus || 'Not started';
    this.testStatus = session.testStatus || 'Not started';
    this.deployStatus = session.deployStatus || 'Not ready';
    this.copadoUserStory = session.copadoUserStory || '';
    this.storyRecordId = session.storyRecordId || '';
    this.storyName = session.storyName || this.parseStoryNumber(session.copadoUserStory);
    this.storyTitle = session.storyTitle || '';
    this.hasStory = !!this.copadoUserStory;
    if (this.hasStory) {
      this.isChangingStory = false;
    }
    if (session.projectId && this.projectOptions.some((o) => o.value === session.projectId)) {
      this.selectedProjectId = session.projectId;
    }
    if (session.selectedOrgId) {
      this.selectedOrgId = session.selectedOrgId;
    }
    this.lastBuildId = session.lastBuildId || '';
    this.lastJobId = session.lastJobId || '';
    this.lastJobStatus = session.lastJobStatus || '';
    this.lastJobSummary = session.lastJobSummary || '';
    this.lastJobFailed = session.lastJobFailed === true;
    this.lastJobComplete = session.lastJobComplete === true;
    this.buildArtifacts = session.buildArtifacts || [];
    // Stop polling as soon as the job reaches a terminal state.
    if (this.lastJobComplete || this.lastJobFailed) {
      this.clearJobPoll();
    }
    // Prefer linked story record for the update picker
    if (session.storyRecordId) {
      this.selectedUserStoryId = session.storyRecordId;
    }
  }

  messagesRenderKey() {
    const parts = (this.messages || []).map(
      (msg) => `${msg.role || ''}:${msg.message || ''}`
    );
    return [
      parts.join('\u0001'),
      this.pendingUserMessage || '',
      this.isLoading ? '1' : '0',
      this.waitingLabel || ''
    ].join('\u0002');
  }

  renderMessages() {
    const container = this.template.querySelector('.chat-messages');
    if (!container) return;

    const key = this.messagesRenderKey();
    if (key === this._lastMessagesKey) {
      return;
    }
    this._lastMessagesKey = key;

    container.innerHTML = '';
    this.messages.forEach((msg) => {
      const bubble = document.createElement('div');
      const role = (msg.role || 'assistant').toLowerCase();
      bubble.className = `message-bubble message-${role}`;
      if (role === 'assistant' || role === 'system') {
        bubble.innerHTML = this.formatCopadoAiHtml(msg.message || '');
      } else {
        bubble.textContent = msg.message || '';
      }
      container.appendChild(bubble);
    });

    // Optimistic user bubble while waiting for Apex round-trip
    if (this.pendingUserMessage) {
      const pending = document.createElement('div');
      pending.className = 'message-bubble message-user';
      pending.textContent = this.pendingUserMessage;
      container.appendChild(pending);
    }

    // Inline typing indicator instead of full-screen spinner
    if (this.isLoading) {
      const typing = document.createElement('div');
      typing.className = 'message-bubble message-assistant message-typing';
      typing.setAttribute('aria-live', 'polite');
      typing.innerHTML =
        `<span class="typing-label">${this.escapeHtml(this.waitingLabel)}</span>` +
        '<span class="typing-dots" aria-hidden="true"><span></span><span></span><span></span></span>';
      container.appendChild(typing);
    }

    const anchor = document.createElement('div');
    anchor.className = 'chat-scroll-anchor';
    anchor.setAttribute('aria-hidden', 'true');
    container.appendChild(anchor);

    this.scrollChatToBottom();
  }

  /**
   * Render Copado AI-style markdown lightly: agent label, bold, bullets, paragraphs.
   */
  formatCopadoAiHtml(raw) {
    if (!raw) return '';
    let text = String(raw).replace(/\r\n/g, '\n');

    // Leading _Build Agent_ / _Plan Agent_ style labels → badge
    let agentBadge = '';
    const agentMatch = text.match(/^_([^_\n]+)_\s*\n+/);
    if (agentMatch) {
      agentBadge = `<div class="msg-agent">${this.escapeHtml(agentMatch[1])}</div>`;
      text = text.slice(agentMatch[0].length);
    }

    const escaped = this.escapeHtml(text);
    const withBold = escaped.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    const lines = withBold.split('\n');
    const htmlParts = [];
    let inList = false;

    const closeList = () => {
      if (inList) {
        htmlParts.push('</ul>');
        inList = false;
      }
    };

    lines.forEach((line) => {
      const bullet = line.match(/^\s*[-•]\s+(.*)$/);
      if (bullet) {
        if (!inList) {
          htmlParts.push('<ul class="msg-list">');
          inList = true;
        }
        htmlParts.push(`<li>${bullet[1]}</li>`);
        return;
      }
      closeList();
      if (line.trim() === '') {
        htmlParts.push('<div class="msg-gap"></div>');
      } else {
        htmlParts.push(`<p class="msg-p">${line}</p>`);
      }
    });
    closeList();

    return agentBadge + htmlParts.join('');
  }

  scrollChatToBottom() {
    if (this._scrollRaf) {
      cancelAnimationFrame(this._scrollRaf);
    }
    const run = () => {
      const container = this.template.querySelector('.chat-messages');
      if (!container) return;
      // Only scroll the chat pane — never scrollIntoView (that can jump the page)
      container.scrollTop = container.scrollHeight;
    };
    // Double rAF so layout (and typing bubble) settles before scrolling
    this._scrollRaf = requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        run();
        // One more tick for Lightning layout / toast chrome
        window.setTimeout(run, 50);
      });
    });
  }

  escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  beginWaiting(label, pendingUserMessage = '') {
    this.clearWaitingTimer();
    this.isLoading = true;
    this.waitingLabel = label || 'Copado is thinking';
    this.pendingUserMessage = pendingUserMessage || '';
    this._waitingTimer = window.setTimeout(() => {
      this.waitingLabel = 'Still working — Copado AI can take a bit';
    }, 15000);
    // Ensure latest content stays visible when actions start
    Promise.resolve().then(() => this.scrollChatToBottom());
  }

  endWaiting() {
    this.clearWaitingTimer();
    this.isLoading = false;
    this.pendingUserMessage = '';
    this.waitingLabel = 'Copado is thinking';
    Promise.resolve().then(() => this.scrollChatToBottom());
  }

  clearWaitingTimer() {
    if (this._waitingTimer) {
      window.clearTimeout(this._waitingTimer);
      this._waitingTimer = undefined;
    }
  }

  handleInputChange(event) {
    this.inputMessage = event.target.value;
  }

  handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.handleSend();
    }
  }

  async handleSend() {
    const text = this.inputMessage?.trim();
    if (!text || this.isLoading) return;

    this.inputMessage = '';
    this._sendGeneration = (this._sendGeneration || 0) + 1;
    const gen = this._sendGeneration;
    this.beginWaiting('Copado is thinking', text);
    try {
      const session = await sendMessage({
        sessionId: this.sessionId,
        message: text,
        // Only the session's connected OI id — never the picker leftover from another chat.
        orgIntelligenceIntegrationId: this.orgIntelligenceIntegrationId || null,
        orgCredentialId: this.selectedOrgId || null
      });
      if (gen !== this._sendGeneration) {
        return;
      }
      this.applySession(session);
      if (session?.awaitingAiReply) {
        this.beginWaiting('Waiting for Copado AI reply');
        await this.pollAiUntilReady(
          session.dialogueId,
          session.aiRequestId,
          session.aiBaselineMessageCount,
          session.aiBaselineAssistantText,
          gen
        );
      }
    } catch (error) {
      if (gen === this._sendGeneration) {
        this.showError(error);
      }
    } finally {
      if (gen === this._sendGeneration) {
        this.endWaiting();
        this.loadChatSessions();
      }
    }
  }

  handleStopWaiting() {
    this._sendGeneration = (this._sendGeneration || 0) + 1;
    this.clearAiPoll();
    this.endWaiting();
    this.showToast('Stopped', 'Stopped waiting for Copado AI. You can send again.', 'info');
    this.loadChatSessions();
  }

  clearAiPoll() {
    if (this._aiPollTimer) {
      // eslint-disable-next-line @lwc/lwc/no-async-operation
      clearTimeout(this._aiPollTimer);
      this._aiPollTimer = null;
    }
    this._aiPollAttempts = 0;
  }

  async pollAiUntilReady(
    dialogueId,
    requestId,
    baselineMessageCount,
    baselineAssistantText,
    generation
  ) {
    this.clearAiPoll();
    // Org Intelligence tool turns often need 1–2 minutes after an empty 201 body.
    const maxAttempts = 60; // ~2 min at 2s interval
    for (let i = 0; i < maxAttempts; i++) {
      if (generation != null && generation !== this._sendGeneration) {
        return;
      }
      this._aiPollAttempts = i + 1;
      if (i > 0) {
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        await new Promise((resolve) => {
          this._aiPollTimer = setTimeout(resolve, 2000);
        });
      }
      if (generation != null && generation !== this._sendGeneration) {
        return;
      }
      const timedOut = i === maxAttempts - 1;
      if (i === 0) {
        this.beginWaiting('Waiting for Copado AI reply');
      } else if (i === 15) {
        this.beginWaiting('Still waiting on Copado AI');
      } else if (i === 35) {
        this.beginWaiting('Almost there — still polling for the reply');
      }
      try {
        const session = await pollAiReply({
          sessionId: this.sessionId,
          dialogueId: dialogueId || null,
          requestId: requestId || null,
          assistantId: 'build',
          timedOut,
          baselineMessageCount:
            baselineMessageCount == null ? null : baselineMessageCount,
          baselineAssistantText: baselineAssistantText || null
        });
        if (generation != null && generation !== this._sendGeneration) {
          return;
        }
        this.applySession(session);
        if (!session?.awaitingAiReply) {
          this.clearAiPoll();
          return;
        }
      } catch (error) {
        if (generation != null && generation !== this._sendGeneration) {
          return;
        }
        this.clearAiPoll();
        this.showError(error);
        return;
      }
    }
    this.clearAiPoll();
  }

  async handleImproveStory() {
    this.scrollChatToBottom();
    await this.runAction(
      () => improveStory({ sessionId: this.sessionId }),
      'Improving your story'
    );
  }

  async handleCreateStory() {
    this.scrollChatToBottom();
    if (!this.selectedProjectId) {
      this.showToast(
        'Select a project',
        'Choose a Copado Project in the Status panel. Dev1 must belong to that project’s pipeline.',
        'warning'
      );
      return;
    }
    await this.runAction(
      () =>
        createCopadoStory({
          sessionId: this.sessionId,
          updateExisting: false,
          targetStoryId: null,
          projectId: this.selectedProjectId
        }),
      'Creating Copado story'
    );
    await Promise.all([this.loadChatSessions(), this.loadUserStories(), this.loadProjects()]);
    await this.loadOrgs();
  }

  handleBuildCode() {
    this.scrollChatToBottom();
    if (!this.hasStory) {
      this.showToast(
        'Link a story first',
        'Create Story or Use Story before building.',
        'warning'
      );
      return;
    }
    const storyLabel = this.linkedStoryNumber || this.copadoUserStory || 'the linked story';
    const confirmed = window.confirm(
      `Build metadata for ${storyLabel}?\n\n`
        + 'Copado Builder will generate the Salesforce metadata package for this story.\n'
        + 'It will not deploy or commit yet — use Commit after Build.'
    );
    if (confirmed) {
      this.executeBuildCode();
    }
  }

  async executeBuildCode() {
    await this.runAction(
      () =>
        buildCode({
          sessionId: this.sessionId,
          environmentId: this.selectedOrgId || null,
          rememberPreference: this.rememberEnvironment
        }),
      'Building metadata'
    );
    await this.loadOrgs();
  }

  async handleRefreshJobStatus() {
    if (!this.sessionId || !this.lastJobId) {
      return;
    }
    await this.runAction(
      () => refreshJobStatus({ sessionId: this.sessionId }),
      'Checking job status'
    );
    if (!this.lastJobComplete && !this.lastJobFailed) {
      this.startJobPoll();
    }
  }

  async handleLinkUserStoryCommit() {
    if (!this.sessionId || !this.lastJobId) {
      return;
    }
    let commitSha = '';
    // If auto-link failed previously due to missing SHA, let the user paste it from the job log.
    if (
      (this.lastJobSummary || '').includes('No SHA found')
      || (this.lastJobSummary || '').includes('could not create/find Snapshot Commit')
    ) {
      commitSha = window.prompt(
        'Paste the git commit SHA from the Copado job log (git rev-parse HEAD line), or leave blank to retry auto-detect:',
        ''
      );
      if (commitSha === null) {
        return;
      }
      commitSha = (commitSha || '').trim();
    }
    await this.runAction(
      () =>
        linkUserStoryCommitFromLastJob({
          sessionId: this.sessionId,
          commitSha: commitSha || null
        }),
      'Linking User Story Commit'
    );
  }

  startJobPoll() {
    this.clearJobPoll();
    if (!this.sessionId || !this.lastJobId || this.lastJobComplete || this.lastJobFailed) {
      return;
    }

    this._jobPollStartedAt = Date.now();
    this._jobPollInFlight = false;
    const maxMs = 10 * 60 * 1000; // hard ceiling only — stop earlier when ready

    const scheduleNext = (delayMs) => {
      this._jobPollTimer = window.setTimeout(pollOnce, delayMs);
    };

    const pollOnce = async () => {
      this._jobPollTimer = null;

      if (!this.lastJobId || this.lastJobComplete || this.lastJobFailed) {
        return;
      }
      if (Date.now() - this._jobPollStartedAt > maxMs) {
        this.showToast(
          'Job still running',
          'Polling timed out. Use Refresh job status or Link commit to story when it finishes.',
          'info'
        );
        return;
      }
      if (this._jobPollInFlight) {
        scheduleNext(3000);
        return;
      }

      this._jobPollInFlight = true;
      try {
        const result = await refreshJobStatus({ sessionId: this.sessionId });
        if (result?.session) {
          this.applySession(result.session);
        }
        // Ready — stop immediately (applySession also clears the timer).
        if (this.lastJobComplete || this.lastJobFailed) {
          return;
        }
      } catch (error) {
        // Transient errors: keep trying until the ceiling.
      } finally {
        this._jobPollInFlight = false;
      }

      if (this.lastJobComplete || this.lastJobFailed) {
        return;
      }

      // Still in progress: poll faster early, then every 10s.
      const elapsed = Date.now() - this._jobPollStartedAt;
      const delayMs = elapsed < 90 * 1000 ? 5000 : 10000;
      scheduleNext(delayMs);
    };

    // First check soon after the job is queued.
    scheduleNext(3000);
  }

  clearJobPoll() {
    if (this._jobPollTimer) {
      window.clearTimeout(this._jobPollTimer);
      this._jobPollTimer = null;
    }
    this._jobPollInFlight = false;
  }

  handleCommitClick() {
    this.scrollChatToBottom();
    if (!this.selectedOrgId) {
      this.showToast(
        'Select a Dev environment',
        'Choose which Dev org to deploy to, then commit from, in the Status panel.',
        'warning'
      );
      return;
    }
    if (!this.hasBuildArtifacts) {
      this.showToast('Build first', 'Run Build so there is a package to commit.', 'warning');
      return;
    }
    const orgName =
      this.orgOptions.find((o) => o.value === this.selectedOrgId)?.label || 'selected Dev environment';
    const confirmed = window.confirm(
      `Commit to the user story via ${orgName}?\n\n`
        + '1. Deploy the package into this Dev org\n'
        + '2. Commit those changes from the org into the story feature branch\n\n'
        + 'Watch Job Status until both steps finish.'
    );
    if (confirmed) {
      this.executeCommit();
    }
  }

  async executeCommit() {
    await this.runAction(
      () =>
        commitFromDev({
          sessionId: this.sessionId,
          environmentId: this.selectedOrgId,
          rememberPreference: this.rememberEnvironment
        }),
      'Deploying to Dev and committing'
    );
    await Promise.all([this.loadChatSessions(), this.loadOrgs()]);
    this.startJobPoll();
  }

  async handleOrgChange(event) {
    this.selectedOrgId = event.detail.value;
    if (!this.sessionId || !this.selectedOrgId) {
      return;
    }
    try {
      const session = await saveSessionOrgCredential({
        sessionId: this.sessionId,
        orgCredentialId: this.selectedOrgId
      });
      this.applySession(session);
      // Re-bind the Copado integration credential to this Dev org (dev1 → dev2).
      await this.syncOrgIntelligence(true);
    } catch (error) {
      // Org picker still works; status refresh is best-effort
    }
  }

  async handleIntegrationChange(event) {
    this.selectedIntegrationId = event.detail.value;
    // Remember choice only — credential bind happens on org change or Connect.
  }

  async handleConnectOrgIntelligence() {
    if (!this.selectedOrgId) {
      this.showToast('Notice', 'Select a Dev environment first.', 'warning');
      return;
    }
    this.beginWaiting('Connecting Org Intelligence');
    try {
      if (!this.integrationsLoaded) {
        await this.loadIntegrations();
      }
      const result = await connectOrgIntelligence({
        sessionId: this.sessionId,
        environmentId: this.selectedOrgId,
        // Do not smoke-test via extra Copado AI dialogues (that created OI Probe / org chat spam).
        askProbeQuestion: false,
        preferredIntegrationId: this.selectedIntegrationId || null
      });
      if (result?.session) {
        this.applySession(result.session);
      }
      if (result?.orgIntelligence?.integrationId) {
        this.orgIntelligenceIntegrationId = result.orgIntelligence.integrationId;
        this.selectedIntegrationId = result.orgIntelligence.integrationId;
      }
      if (result?.session?.orgContextStatus) {
        this.orgContextStatus = result.session.orgContextStatus;
      } else if (result?.success) {
        this.orgContextStatus = 'Connected';
      }
      if (result?.success) {
        this.showToast('Success', result.message || 'Org Intelligence connected.', 'success');
      } else {
        this.showToast(
          'Org Intelligence',
          result?.message || 'Could not connect. Check the System message for API details.',
          'warning'
        );
      }
      // Refresh list so status labels stay current
      await this.loadIntegrations();
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
    }
  }

  async handleProjectChange(event) {
    this.selectedProjectId = event.detail.value;
    this.selectedOrgId = '';
    try {
      if (this.selectedProjectId) {
        await savePreferredProject({ projectId: this.selectedProjectId });
      }
    } catch (error) {
      // Preference is best-effort; still reload orgs for the selected project
    }
    await this.loadOrgs();
  }

  handleRememberEnvironmentChange(event) {
    this.rememberEnvironment = event.target.checked;
  }

  handleUserStoryChange(event) {
    this.selectedUserStoryId = event.detail.value;
  }

  async runAction(actionFn, waitingLabel = 'Working on it') {
    this.beginWaiting(waitingLabel);
    try {
      const result = await actionFn();
      if (result?.session) {
        this.applySession(result.session);
      }
      if (result?.success) {
        this.showToast('Success', result.message || 'Done.', 'success');
      } else {
        this.showToast('Notice', result?.message || 'Action did not complete.', 'warning');
      }
    } catch (error) {
      this.showError(error);
    } finally {
      this.endWaiting();
      this.loadChatSessions();
    }
  }

  showError(error) {
    const message =
      error?.body?.message ||
      error?.body?.pageErrors?.[0]?.message ||
      error?.body?.fieldErrors?.[Object.keys(error?.body?.fieldErrors || {})[0]]?.[0]?.message ||
      error?.message ||
      (typeof error === 'string' ? error : null) ||
      JSON.stringify(error?.body || error) ||
      'Something went wrong.';
    this.showToast('Error', message, 'error');
  }

  showToast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }

  get scoreDisplay() {
    return `${this.score}%`;
  }

  get scoreClass() {
    if (this.score >= 75) return 'status-value score-good';
    if (this.score >= 50) return 'status-value score-medium';
    return 'status-value score-low';
  }

  get missingInfoDisplay() {
    return this.missingInfo.length > 0 ? this.missingInfo.join(', ') : 'None';
  }

  get isCreateStoryDisabled() {
    return this.isLoading || this.score < 40 || !this.selectedProjectId;
  }

  get isUpdateStoryDisabled() {
    return this.isLoading || this.score < 40 || !this.selectedUserStoryId;
  }

  get showStoryPicker() {
    return !this.hasStory || this.isChangingStory;
  }

  get storyPickerHeading() {
    return this.hasStory ? 'Switch story' : 'Link a Copado Story';
  }

  get storyChangeButtonLabel() {
    return this.isChangingStory ? 'Cancel' : 'Change';
  }

  get isStoryLinkDisabled() {
    return !this.storyRecordId;
  }

  get isUseStoryDisabled() {
    return this.isLoading || !this.selectedUserStoryId;
  }

  get showProjectSelect() {
    return this.projectOptions.length > 0;
  }

  get hasBuildArtifacts() {
    return this.buildArtifacts && this.buildArtifacts.length > 0;
  }

  get artifactsDisplay() {
    if (!this.buildArtifacts || this.buildArtifacts.length === 0) {
      return 'None';
    }
    return this.buildArtifacts
      .map((p) => {
        const parts = String(p).split('/');
        return parts[parts.length - 1] || p;
      })
      .join(', ');
  }

  get showOrgSelect() {
    // Available before a story exists — Org Intelligence improves discovery/requirements.
    return !!this.sessionId;
  }

  get showIntegrationSelect() {
    return this.showOrgSelect && this.integrationOptions.length > 0;
  }

  get orgSelectDisabled() {
    return this.orgOptions.length === 0;
  }

  parseStoryNumber(label) {
    if (!label) return '';
    const parts = String(label).split(' — ');
    return parts[0]?.trim() || label;
  }

  get linkedStoryNumber() {
    return this.storyName || this.parseStoryNumber(this.copadoUserStory);
  }

  get linkedStoryTitle() {
    return this.storyTitle || '';
  }

  async handleOpenLinkedStory(event) {
    if (event) {
      event.preventDefault();
    }
    if (!this.storyRecordId) return;
    try {
      const url = await this[NavigationMixin.GenerateUrl]({
        type: 'standard__recordPage',
        attributes: {
          recordId: this.storyRecordId,
          objectApiName: 'copado__User_Story__c',
          actionName: 'view'
        }
      });
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (error) {
      this.showError(error);
    }
  }

  handleChangeStory() {
    this.isChangingStory = !this.isChangingStory;
    if (!this.isChangingStory) {
      return;
    }
    const combo = this.template.querySelector('[data-id="existing-story-combo"]');
    if (combo) {
      combo.focus();
    }
  }

  get isOrgIntelligenceDisabled() {
    return this.isLoading || !this.selectedOrgId;
  }

  get orgIntelligenceButtonLabel() {
    return this.isOrgContextConnected
      ? 'Reconnect Org Intelligence'
      : 'Connect Org Intelligence';
  }

  get orgIntelligenceButtonVariant() {
    return this.isOrgContextConnected ? 'neutral' : 'brand';
  }

  get orgIntelligenceButtonTitle() {
    return this.isOrgContextConnected
      ? 'Already connected — click to re-bind this Dev org on the selected Copado integration'
      : 'Attach the selected Copado AI integration and bind it to this Dev org';
  }

  get selectedOrgLabel() {
    if (!this.selectedOrgId) {
      return '';
    }
    const match = (this.orgOptions || []).find((o) => o.value === this.selectedOrgId);
    return match?.label || this.selectedOrgId;
  }

  get isOrgContextConnected() {
    return (this.orgContextStatus || '').toLowerCase() === 'connected';
  }

  get orgContextDisplay() {
    if (!this.isOrgContextConnected) {
      return 'Not connected';
    }
    return this.selectedOrgLabel || 'Connected';
  }

  get orgContextTitle() {
    if (!this.selectedOrgLabel) {
      return 'Select a Dev environment. Connected integrations attach automatically.';
    }
    if (this.isOrgContextConnected) {
      return `Connected to ${this.selectedOrgLabel} via Copado Org Intelligence.`;
    }
    return `${this.selectedOrgLabel} is selected. Waiting for a connected Copado AI integration.`;
  }

  get orgContextStatusClass() {
    return this.isOrgContextConnected
      ? 'status-value status-connected'
      : 'status-value status-disconnected';
  }

  get isBuildDisabled() {
    return this.isLoading || !this.hasStory;
  }

  get isStoryActionDisabled() {
    return this.isLoading || !this.hasStory;
  }

  get isCommitDisabled() {
    return (
      this.isLoading
      || !this.hasStory
      || !this.selectedOrgId
      || !this.hasBuildArtifacts
    );
  }

  get isRefreshJobDisabled() {
    return this.isLoading || !this.lastJobId;
  }

  /** Recovery only — hide once USC is linked or while the job is still running. */
  get showLinkCommitButton() {
    if (!this.lastJobId || !this.lastJobComplete || this.lastJobFailed) {
      return false;
    }
    const detail = (this.lastJobSummary || '').toLowerCase();
    if (
      detail.includes('already linked')
      || detail.includes('linked user story commit')
    ) {
      return false;
    }
    return (
      detail.includes('usc link failed')
      || detail.includes('skip usc link')
      || detail.includes('no sha found')
      || detail.includes('could not create')
    );
  }

  get lastJobStatusDisplay() {
    if (!this.lastJobId) {
      return 'None';
    }
    return this.lastJobStatus || 'Unknown';
  }

  /** True when Last_Job_Id__c is a Salesforce record Id (not mock/webhook placeholder). */
  get hasJobRecordLink() {
    const id = (this.lastJobId || '').trim();
    return /^[a-zA-Z0-9]{15}([a-zA-Z0-9]{3})?$/.test(id);
  }

  get jobStatusClass() {
    if (this.lastJobFailed) {
      return 'status-value score-low';
    }
    if (this.lastJobComplete) {
      return 'status-value score-good';
    }
    return 'status-value score-medium';
  }

  get jobStatusLinkClass() {
    return `${this.jobStatusClass} story-hotlink status-job-link`;
  }

  async handleOpenLastJob(event) {
    if (event) {
      event.preventDefault();
    }
    if (!this.hasJobRecordLink) {
      return;
    }
    try {
      const url = await this[NavigationMixin.GenerateUrl]({
        type: 'standard__recordPage',
        attributes: {
          recordId: this.lastJobId,
          objectApiName: 'copado__JobExecution__c',
          actionName: 'view'
        }
      });
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (error) {
      // Fallback: bare record Id URL works in Lightning even if API name differs.
      window.open('/' + this.lastJobId, '_blank', 'noopener,noreferrer');
    }
  }

  get hasChatSessions() {
    return this.chatSessions && this.chatSessions.length > 0;
  }

  get chatSessionsView() {
    const activeId = this.sessionId;
    return (this.chatSessions || []).map((chat) => ({
      ...chat,
      itemClass:
        chat.sessionId === activeId ? 'chat-item chat-item-active' : 'chat-item'
    }));
  }
}
